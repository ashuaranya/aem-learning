(function (document, $) {
    "use strict";

    function manageDialogView(selectedValue) {
        var $multiField = $("[data-id='carousel-feature']");
        var $multiImageField = $("[data-id='carousel-image']");
        // Show or hide the component selection multifield based on the selected value
        if (selectedValue === "Feature") {
            $multiField.show();
            $multiImageField.hide();
        } else if (selectedValue === "ImageGallery") {
            $multiImageField.show();
            $multiField.hide();
        } else {
            $multiField.hide();
            $multiImageField.hide();
        }
    }

    $(document).on("dialog-ready", function () {
        var $carouselType = $("[name='./carouselType']");
        // Get the carouselType dropdown
        setTimeout(() => {
             // Trigger the change event on page load to set the initial state
            $carouselType.trigger("change");
        }, 100);
       
        // Add change event listener
        $carouselType.on("change", function () {
            var selectedValue = $(this).val();
            manageDialogView(selectedValue);
        });
    });
})(document, Granite.$);

(function(channel) {
    "use strict";

    channel.on("cq-editor-loaded", function(event) {
        if (window.CQ && window.CQ.CoreComponents && window.CQ.CoreComponents.panelcontainer &&
            window.CQ.CoreComponents.panelcontainer.v1 && window.CQ.CoreComponents.panelcontainer.v1.registry) {
            window.CQ.CoreComponents.panelcontainer.v1.registry.register({
                name: "cmp-carousel",
                selector: ".cmp-carousel",
                wrapperSelector: '[data-panelcontainer="carousel"]',
                itemSelector: "[data-cmp-hook-carousel='item']",
                itemActiveSelector: ".cmp-carousel__item--active",
                itemSelectorWrapper: ".cmp-carousel__content"
            });
        }
    });

})(jQuery(document));